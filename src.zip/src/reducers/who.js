import whoJson from './data/who.json';

const initialState = {
    who: whoJson
}

const who = (state = initialState) => {
    return(state);
};

export default who;