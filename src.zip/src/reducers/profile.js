import owner from './data/profile.json';

const initialState = {
    profile: owner
};

const profile = (state = initialState, action) =>{
    switch(action.type){
        case 'save-information':
           
            if(action.newInput.name){
                initialState.profile['firstName'] = action.newInput['name'].split(" ")[0];
                initialState.profile['lastName'] = action.newInput['name'].split(" ")[1];
            }
            if(action.newInput.bio){
                initialState.profile['bio'] = action.newInput['bio'];

            }

            console.log("reducer state");
            console.log(action.newInput)
            return {

                ...state,
                   
            };        
            default:
                return (state)
                    
                     
                
    }
}

export default profile;