/* eslint-disable import/no-anonymous-default-export */


export default [
    {   title: 'Buy milk', status: 'CANCELED',
        done: true,
    },
    {   title: 'Pickup the kids', status: 'IN PROGRESS',
        done: false,
    },
    {   title: 'Walk the dog', status: 'DEFERRED',
        done: false,
    },];

